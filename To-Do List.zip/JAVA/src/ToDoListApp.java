import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ToDoListApp {
    private DatabaseHelper db;
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private JTextField taskField;

    public ToDoListApp() {
        db = new DatabaseHelper();
        frame = new JFrame("To-Do List");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Top Panel
        JPanel panel = new JPanel();
        taskField = new JTextField(20);
        JButton addButton = new JButton("Add Task");
        JButton deleteButton = new JButton("Delete Task");
        JButton editButton = new JButton("Edit Task");
        JButton completeButton = new JButton("Mark as Completed");

        panel.add(taskField);
        panel.add(addButton);
        panel.add(deleteButton);
        panel.add(editButton);
        panel.add(completeButton);

        // Table
        // Table
        model = new DefaultTableModel(new String[]{"ID", "Task", "Status"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // Load tasks after setting up table
        loadTasks();


        // Button Actions
        addButton.addActionListener(e -> addTask());
        deleteButton.addActionListener(e -> deleteTask());
        editButton.addActionListener(e -> editTask());
        completeButton.addActionListener(e -> markAsCompleted());

        // Add components to frame
        frame.add(panel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private void loadTasks() {
    model.setRowCount(0);
    List<String[]> tasks = db.getTasks();
    if (tasks.isEmpty()) {
        System.out.println("No tasks found in the database.");
    }
    for (String[] task : tasks) {
        System.out.println("Loading Task: " + task[0] + " - " + task[1] + " - " + task[2]); // Debugging output
        model.addRow(task);
    }
}


    private void addTask() {
        String task = taskField.getText().trim();
        if (!task.isEmpty()) {
            db.addTask(task);
            taskField.setText("");
            loadTasks();
        } else {
            JOptionPane.showMessageDialog(frame, "Task cannot be empty!");
        }
    }

    private void deleteTask() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int id = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
            db.deleteTask(id);
            loadTasks();
        } else {
            JOptionPane.showMessageDialog(frame, "Please select a task to delete.");
        }
    }

    private void editTask() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String newTask = JOptionPane.showInputDialog(frame, "Edit Task:", model.getValueAt(selectedRow, 1));
            if (newTask != null && !newTask.trim().isEmpty()) {
                int id = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
                db.updateTask(id, newTask);
                loadTasks();
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Please select a task to edit.");
        }
    }

    private void markAsCompleted() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int id = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
            db.markAsCompleted(id);
            loadTasks();
        } else {
            JOptionPane.showMessageDialog(frame, "Please select a task to mark as completed.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ToDoListApp::new);
    }
}
