import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper {
    private static final String URL = "jdbc:mysql://localhost:3306/todo_app";
    private static final String USER = "root";  // Change if needed
    private static final String PASSWORD = "t_jyotika";  // Change if needed

    public DatabaseHelper() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement()) {
            String createTable = "CREATE TABLE IF NOT EXISTS tasks (" +
                    "id INT PRIMARY KEY AUTO_INCREMENT," +
                    "description VARCHAR(255) NOT NULL," +
                    "status VARCHAR(20) DEFAULT 'Pending'," +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
            stmt.execute(createTable);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addTask(String description) {
        String sql = "INSERT INTO tasks (description) VALUES (?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, description);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String[]> getTasks() {
    List<String[]> tasks = new ArrayList<>();
    String sql = "SELECT id, description, status FROM tasks ORDER BY id ASC";
    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {
        while (rs.next()) {
            System.out.println("Fetched Task: " + rs.getInt("id") + " - " + rs.getString("description"));
            tasks.add(new String[]{
                    String.valueOf(rs.getInt("id")),
                    rs.getString("description"),
                    rs.getString("status")
            });
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return tasks;
}

    public void deleteTask(int id) {
        String sql = "DELETE FROM tasks WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateTask(int id, String newDescription) {
        String sql = "UPDATE tasks SET description = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newDescription);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void markAsCompleted(int id) {
        String sql = "UPDATE tasks SET status = 'Completed' WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
